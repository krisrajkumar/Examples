package com.example.callingserver;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.Activity;
import android.app.ProgressDialog;
import android.util.Log;
import android.view.Menu;
import android.widget.Toast;

public class MainActivity extends Activity {
	HTTPConnect connect = new HTTPConnect();
	String url = "", str = "",value = "";
	String latitude = null;
	String longitude = null;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		new Thread(){
			public void run(){
				
				str = connect.getInputStream("http://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false");
				Log.v("Str", str);
				jsonParser(str);
				msgHandler.sendEmptyMessage(1);
			}
		}.start();
		
	/*	new Thread(){
			public void run(){
				str = connect.getInputStream("http://maps.googleapis.com/maps/api/geocode/json?address=1600+Amphitheatre+Parkway,+Mountain+View,+CA&sensor=false");
				Log.v("Str", str);
				msgHandler.sendEmptyMessage(2);
			}
		}.start();*/
	}
	private void jsonParser(String str) {
		// TODO Auto-generated method stub
		try {
			// I am passing the json string received 
			JSONObject jsonObj = new JSONObject(str);
			// Results array is extracted here
			JSONArray jsonArray = jsonObj.getJSONArray("results");
			// I am getting the first index of the JSONArray (i.e) address components
			String strArray = jsonArray.getString(0);
			Log.v("Array", strArray);
			JSONObject json = new JSONObject(strArray);
			// Getting the values in the geometry node
			JSONObject jsonGeo = json.getJSONObject("geometry");
			
			Log.v("Geo", jsonGeo.getString("location"));

			JSONObject jsonLoc = new JSONObject(jsonGeo.getString("location"));
			
			latitude = jsonLoc.getString("lat");
			longitude = jsonLoc.getString("lng");

			msgHandler.sendEmptyMessage(1);
		} catch (JSONException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}
	Handler msgHandler = new Handler(){
		public void handleMessage(Message msg){
			super.handleMessage(msg);
			if(msg.what == 1){
				Toast.makeText(getApplicationContext(),"Latitude:"+latitude+" Longitude:"+longitude, Toast.LENGTH_SHORT).show();
			}
			if(msg.what == 2){
				Toast.makeText(getApplicationContext(),"Thread2", Toast.LENGTH_LONG).show();
			}
		}
	};
}